﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;  // 추가
using System.Data.SqlClient; // 
using System.Data;
using System.Configuration;

namespace project12
{
    public partial class realLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.User.Identity.IsAuthenticated)
                Response.Redirect(FormsAuthentication.DefaultUrl);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (IsAuthenticated(TextBox1.Text, TextBox2.Text))  // DB에 존재하는 사용자인가
            {
                FormsAuthentication.RedirectFromLoginPage(TextBox1.Text, CheckBox1.Checked);
                // 현재 브라우저에서만 로그인되게 하겠다! 라는 의미로 보안상 false가 제일 안전
            }
            else
            {
                Label2.Text = "아이디 또는 암호가 일치하지 않습니다.";
            }
        }

        private bool IsAuthenticated(string userID, string password)
        {
            // DB에 연동하여 확인 작업 필요
            bool result = false;

            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령
            string sql = @"Select * from Company Where UserID=@UserID and Password=@Password";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@UserID", userID);
            cmd.Parameters.AddWithValue("@Password", password);

            // 실행
            con.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
                result = true;
            else
                result = false;
            rd.Close();
            con.Close();

            return result;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {  
            TextBox1.Text = "";
            TextBox2.Text = "";

            if (CheckBox1.Checked)
                CheckBox1.Checked = false;  
            
           
        }

    
    }
}