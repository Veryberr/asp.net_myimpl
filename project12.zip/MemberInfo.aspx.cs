﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;  // 추가
using System.Data.SqlClient; // 
using System.Data;
using System.Configuration;

namespace project12
{
    public partial class MemberInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        { // 이름 일부 입력
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령(sql 문)
            string sql = "Select Name,Phone,State,Part From Company Where Name like '%' + @Name + '%'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@Name", TextBox1.Text); // 파라미터 정의 및 값 지정

            // 실행 및 화면 표시
            con.Open();
            GridView1.DataSource = cmd.ExecuteReader();
            if (TextBox1.Text == "")
            {
                Label3.Text = "이름을 입력하세요";
                GridView1.DataSource = "";
            }
            else
                Label3.Text = "";
            GridView1.DataBind();
            con.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            // 파트 일부 입력
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령(sql 문)
            string sql = "Select Name,Part From Company Where Part like '%' + @Part + '%'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@Part", TextBox2.Text); // 파라미터 정의 및 값 지정

            // 실행 및 화면 표시
            con.Open();
            GridView2.DataSource = cmd.ExecuteReader();
            if (TextBox2.Text == "")
            {
                Label2.Text = "파트를 입력하세요";
                GridView2.DataSource = "";
            }
            else
                Label2.Text = "";
            GridView2.DataBind();
            con.Close();
        }
    }
}