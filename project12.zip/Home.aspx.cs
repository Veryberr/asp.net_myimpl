﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;  // 추가
using System.Data.SqlClient; // 
using System.Data;
using System.Configuration;

namespace project12
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.User.Identity.IsAuthenticated)
            { // 로그인 상태 유지 = 다른 브라우저에서 열어도 로그인 유지
                
                
                Button3.Visible = true;
            }
            else
            {
               
               
                Button3.Visible = false;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
               
            Button3.Visible = false;

        }
        

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("PrivacyModify.aspx");
        }
    }
}