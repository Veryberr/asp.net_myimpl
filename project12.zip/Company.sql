﻿use Master;
create Table Company (
	UserID varchar(30) primary key,
	Password varchar(30) not null,
	Name varchar(30) not null,
	Phone varchar(30),
	State varchar(10),
	Part varchar(20) 
)

Insert into Company Values ('admin','1111','관리자','','','')
Insert into Company Values ('hsnam','1111','남현서','010-1111-1111','재직','버거 파트')
Insert into Company Values ('hee123','1111','김수희','010-2222-2222','재직','홀 파트')
Insert into Company Values ('suhyun','1111','이수현','010-3333-3333','재직','버거 파트')
Insert into Company Values ('smile55','1111','서이수','010-4444-4444','재직','튀김 파트')
Insert into Company Values ('snowman','1111','박희원','010-5555-5555','재직','홀 파트')
Insert into Company Values ('gold33','1111','박이나','010-6666-6666','재직','튀김 파트')
Insert into Company Values ('bean11','1111','김영자','010-7777-7777','퇴사','버거 파트')
Insert into Company Values ('rice00','1111','박은미','010-8888-8888','퇴사','튀김 파트')

select * from Company