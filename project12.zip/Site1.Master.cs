﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace project12
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.User.Identity.IsAuthenticated)
            { // 로그인 상태 유지 = 다른 브라우저에서 열어도 로그인 유지
                Label1.Text = Page.User.Identity.Name + "님, 환영합니다!";
                Button1.Visible = false;
                Button2.Visible = true;
                Button3.Visible = false;
            }
            else
            {
                Label1.Text = "";
                Button1.Visible = true;
                Button2.Visible = false;
                Button3.Visible = true;
            }


            if (Page.User.Identity.Name == "admin")
            {
                HyperLink3.Visible = true;
            }
            else
                HyperLink3.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("realLogin.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            
            FormsAuthentication.SignOut(); // 인증 쿠키만 없애줌
            Button1.Visible = true;
            Button2.Visible = false;
            Response.Redirect("Home.aspx");
           

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Member.aspx");
        }

       
    }
}