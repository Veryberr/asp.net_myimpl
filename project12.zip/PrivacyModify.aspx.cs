﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;  // 추가
using System.Data.SqlClient; // 
using System.Data;
using System.Configuration;

namespace project12
{
    public partial class PrivacyModify : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string id = User.Identity.Name;

                string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
                SqlConnection con = new SqlConnection(conStr);
                string sql = "Select * from Company where UserID = @UserID";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@UserID", id);

                con.Open();
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    Label2.Text = id;
                    TextBox3.Text = rd["Name"].ToString();
                    TextBox4.Text = rd["Phone"].ToString();
                    TextBox5.Text = rd["State"].ToString();
                    TextBox6.Text = rd["Part"].ToString();
                }
                rd.Close();
                con.Close();
            }

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            // 변경
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령
            string sql = @"update Company Set Password=@Password, Name=@Name,Phone=@Phone,State=@State,Part=@Part
                            Where UserID=@UserID";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@Password", TextBox1.Text);
            cmd.Parameters.AddWithValue("@Name", TextBox3.Text);
            cmd.Parameters.AddWithValue("@Phone", TextBox4.Text);
            cmd.Parameters.AddWithValue("@State", TextBox5.Text);
            cmd.Parameters.AddWithValue("@Part", TextBox6.Text);
            cmd.Parameters.AddWithValue("@UserID", Page.User.Identity.Name);

            // 실행
            con.Open();
            int a = cmd.ExecuteNonQuery();
            con.Close();

            if (a > 0)
            {
                string str = @"<script> alert('정보가 변경되었습니다'); ";
                str += "location.href = '/Home.aspx'; </script> ";
                Response.Write(str);
            }
            else
                Label3.Text = "정보변경에 실패했습니다.";
        }
    }
    
}