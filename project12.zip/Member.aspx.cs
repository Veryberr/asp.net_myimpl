﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;  // 추가
using System.Data.SqlClient; // 
using System.Data;
using System.Configuration;

namespace project12
{
    public partial class Member : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        { // 완료 버튼
            AddMember();
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Member.aspx");

        }

        private bool IsMemberExists()
        {
            bool result = true;
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령
            string sql = @"Select * from Company Where UserID=@UserID";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@UserID", TextBox1.Text);

            // 실행
            con.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
                result = true;
            else
                result = false;
            rd.Close();
            con.Close();
            return result;
        }

        private void AddMember()
        {
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령
            string sql = @"Insert into Company Values (@UserID, @Password, @Name, @Phone, @State, @Part)";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@UserID", TextBox1.Text);
            cmd.Parameters.AddWithValue("@Password", TextBox2.Text);
            cmd.Parameters.AddWithValue("@Name", TextBox4.Text);
            cmd.Parameters.AddWithValue("@Phone", TextBox5.Text);
            cmd.Parameters.AddWithValue("@State", DropDownList1.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@Part", DropDownList2.SelectedItem.Value);
            

            // 실행
            con.Open();
            int a = cmd.ExecuteNonQuery();
            con.Close();

            if (a > 0)
            {
                FormsAuthentication.SetAuthCookie(TextBox1.Text, false); // 인증쿠키를 생성
                string str = @"<script> alert('회원에 가입되셨습니다.'); ";
                str += "location.href = '/Home.aspx'; </script> ";
                Response.Write(str);
            }
            else
                Label2.Text = "회원가입에 실패했습니다.";
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string str = "<script> window.open('ConfirmID.aspx?id=" + TextBox1.Text
                + "','mywindow','top=200,left=200,width=400,height=200'); </script>";
            Response.Write(str);
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Button1.Enabled = (DropDownList2.SelectedValue == "- 선택하세요 -") ? false : true;
        }
    }
}