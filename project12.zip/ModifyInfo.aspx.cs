﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;  // 추가
using System.Data.SqlClient; // 
using System.Data;
using System.Configuration;

namespace project12
{
    public partial class ModifyInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string id = Page.User.Identity.Name;
                // DB에서 이 id의 레코드 값을 읽어와서 화면에 보여준다 

                // 연결
                string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
                SqlConnection con = new SqlConnection(conStr);

                // 명령
                string sql = @"Select * from Company Where UserID=@UserID";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@UserID", DropDownList3.SelectedValue);

                // 실행
                con.Open();
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    TextBox1.Text = rd["Password"].ToString();
                    TextBox2.Text = rd["Password"].ToString();
                    TextBox3.Text = rd["Name"].ToString();
                    TextBox6.Text = rd["Phone"].ToString();
                    TextBox7.Text = rd["State"].ToString();
                    TextBox8.Text = rd["Part"].ToString();
                }
                rd.Close();
                con.Close();

                BindMember();
                SetInfo();  
            }
        }

        private void SetInfo()
        {
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령(sql 문)
            string sql = "Select * From Company Where UserID = @UserID";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@UserID", DropDownList3.SelectedValue); // 파라미터 지정

            // 실행 및 화면 표시
            con.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                TextBox1.Text = rd["Password"].ToString();
                TextBox2.Text = rd["Password"].ToString();
                TextBox3.Text = rd["Name"].ToString();
                TextBox6.Text = rd["Phone"].ToString();
                TextBox7.Text = rd["State"].ToString();
                TextBox8.Text = rd["Part"].ToString();

                Label2.Text = DropDownList3.SelectedValue + " 님이 선택되었습니다.";
            }
            else
            {
                Label2.Text = "아이디가 선택되지 않았습니다.";
            }
            con.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        { // 변경
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령
            string sql = @"update Company Set Password=@Password, Name=@Name,Phone=@Phone,State=@State,Part=@Part
                            Where UserID=@UserID";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@Password", TextBox2.Text);
            cmd.Parameters.AddWithValue("@Name", TextBox3.Text);
            cmd.Parameters.AddWithValue("@Phone", TextBox6.Text);
            cmd.Parameters.AddWithValue("@State", TextBox7.Text);
            cmd.Parameters.AddWithValue("@Part", TextBox8.Text);
            cmd.Parameters.AddWithValue("@UserID", Page.User.Identity.Name);

            // 실행
            con.Open();
            int a = cmd.ExecuteNonQuery();
            con.Close();

            if (a > 0)
            {
                string str = @"<script> alert('정보가 변경되었습니다'); ";
                str += "location.href = '/Home.aspx'; </script> ";
                Response.Write(str);
            }
            else
                Label2.Text = "정보변경에 실패했습니다.";
        }

        protected void Button2_Click(object sender, EventArgs e)
        { // 전체 직원 정보
            Response.Redirect("Login.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        { // 삭제
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령(sql 문)
            string sql = @"Delete from Company Where UserID=@UserID";
            SqlCommand cmd = new SqlCommand(sql, con);

            cmd.Parameters.AddWithValue("@UserID", DropDownList3.SelectedValue); // 파라미터 정의 및 값 지정

            // 실행 및 화면 표시
            try
            {
                con.Open();
                int num = cmd.ExecuteNonQuery(); // 실행 쿼리 (입력, 삭제, 수정 기능을 하는 쿼리) -> 실제 DB에서 실행
                con.Close();

                
                if (num > 0)
                    Label2.Text = DropDownList3.SelectedItem.Text + "의 정보가 삭제되었습니다.";
                else
                    Label2.Text = "삭제에 실패했습니다.";
            }
            catch (Exception ex)
            {
                Label2.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }

            BindMember();
        }

        private void BindMember()
        {
            DropDownList3.DataBind();
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령(sql 문)
            string sql = "Select UserID From Company";
            SqlCommand cmd = new SqlCommand(sql, con);

            // 실행 및 화면 표시
            con.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            DropDownList3.DataSource = rd;
            DropDownList3.DataTextField = "UserID";
            DropDownList3.DataValueField = "UserID";
            DropDownList3.DataBind();
            
            con.Close();
        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetInfo(); // 선택내용으로 채우기 


        }

        protected void DropDownList3_DataBound(object sender, EventArgs e)
        {
            DropDownList3.Items.Insert(0, new ListItem("- 선택하세요 -", "-1"));

        }


    }
}