﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;  // 추가
using System.Data.SqlClient; // 
using System.Data;
using System.Configuration;

namespace project12
{
    public partial class Privacy : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindMember();
                SetInfo();  // 아래의 5개 필드값을 채운다.
            }
        }

        private void BindMember()
        {
            DropDownList1.DataBind();
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령(sql 문)
            string sql = "Select UserID From Company";
            SqlCommand cmd = new SqlCommand(sql, con);

            // 실행 및 화면 표시
            con.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            DropDownList1.DataSource = rd;
            DropDownList1.DataTextField = "UserID";
            DropDownList1.DataValueField = "UserID";
            DropDownList1.DataBind();

            con.Close();
        }

        private void SetInfo()
        {
            // 연결
            string conStr = ConfigurationManager.ConnectionStrings["master"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            // 명령(sql 문)
            string sql = "Select * From Company Where UserID = @UserID";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@UserID", DropDownList1.SelectedValue); // 파라미터 지정

            // 실행 및 화면 표시
            con.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                TextBox1.Text = rd["Name"].ToString();
                TextBox2.Text = rd["Phone"].ToString();
                TextBox3.Text = rd["State"].ToString();
                TextBox4.Text = rd["Part"].ToString();

                Label2.Text = DropDownList1.SelectedValue + " 님이 선택되었습니다.";
            }
            else
            {
                Label2.Text = "아이디가 선택되지 않았습니다.";
            }
            con.Close();
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetInfo(); // 선택내용으로 채우기 
        }

        protected void DropDownList1_DataBound(object sender, EventArgs e)
        {
            DropDownList1.Items.Insert(0, new ListItem("- 선택하세요 -", "-1"));

        }

        protected void Button1_Click(object sender, EventArgs e)
        { // Home으로 돌아가기
            Response.Redirect("Home.aspx");
        }
    }
}